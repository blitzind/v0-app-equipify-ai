# @fuzor/identity

Fuzor platform Identity — the sixth runtime capability extracted from the canonical Equipify AI OS identity substrate (GE-AIOS-2A actor catalog, GE-AIOS-2B event attribution, GE-AIOS-PRODUCTION-VALIDATION-1B workspace organization resolution, GE-AI-UX-3A/3B persona presentation and persistence).

## Purpose

Identity is a **contract-first** platform package. Equipify does not expose one monolithic identity service; reusable platform behavior lives in shared catalogs, resolution ports, normalization rules, and organization-scoped persona persistence. This package extracts that substrate without authentication, authorization, product CRM identity, or messaging sender identity.

**Identity represents references and resolution — not proof of who someone is.**

## Canonical sources

| Module | Equipify source |
|--------|-----------------|
| Platform actors | `lib/growth/aios/ai-work-order-types.ts` (`AI_WORK_ORDER_AGENTS`) |
| Event attribution | `lib/growth/aios/ai-event-types.ts` (`producer`, `source`, `agentOwner`) |
| Organization resolution | `lib/growth/growth-engine-workspace-organization.ts` |
| Persona presentation | `lib/workspace/ai-teammate-identity.ts` |
| Persona server types | `lib/growth/settings/growth-ai-teammate-identity-types.ts` |
| Persona persistence | `lib/growth/settings/growth-ai-teammate-identity-repository.ts` |
| Persona service | `lib/growth/settings/growth-ai-teammate-identity-service.ts` |

## Public interfaces

| Export | Responsibility |
|--------|----------------|
| `PLATFORM_ACTOR_AGENTS` / `isPlatformActorAgent` | Seventeen constitutional platform actor keys |
| `normalizePlatformEventAttribution` | Producer/source/agentOwner reference normalization |
| `resolvePlatformWorkspaceOrganizationId` | AI OS workspace organization resolution (explicit UUID or configured default) |
| `resolvePlatformOrganizationId` | Nullable organization id coalescing |
| `setPlatformIdentityDefaultOrganizationId` | Injectable default org boundary (replaces Equipify access) |
| `normalizePlatformPersonaName` / `sanitizePlatformPersonaName` | Persona display name normalization |
| `resolvePlatformPersonaPresentation` | Presentation bundle (name, role, pronouns) |
| `loadPlatformPersonaIdentity` / `updatePlatformPersonaIdentity` | Organization-scoped persona identity load/update |
| `getPlatformOrganizationPersonaRecord` | Organization-scoped persona persistence read |
| `platformPersonaSchemaCatalog` | Documented persistence contract (no migrations) |

## Actor categories

| Category | In this package | Notes |
|----------|-----------------|-------|
| **Platform actor** | `PlatformActorAgent` (17 keys) | Constitutional specialist agents + `executive_brain` requester |
| **Autonomous agent** | Same catalog | Work-order owner/assigned agent vocabulary |
| **Specialist** | Not centralized here | Equipify `AvaSpecialistId` registry is separate (5 keys) |
| **Persona** | Presentation + org-scoped name | Default display name "Ava" is historical default, not platform identity |
| **Human user** | Referenced by id only | No authentication |
| **Organization** | UUID resolution + scoping | Tenant boundary for persona lookup |
| **Product / company** | Documented constant only | `PLATFORM_DOCUMENTED_AI_OS_PRODUCTION_ORG_ID` is documentation, not runtime fallback |
| **Service process** | Free-form `producer` / `source` strings on events | No central registry |

## Organization scoping and tenant isolation

- Persona persistence queries always filter by `organization_id`.
- Workspace organization resolution accepts explicit override (validated UUID) or configured default.
- Missing organization context returns default persona presentation without cross-tenant lookup.
- Entity or actor IDs cannot bypass organization scope in persona repository paths.

## Boundary adaptations

| Equipify dependency | Fuzor replacement |
|--------------------|-------------------|
| `getGrowthEngineAiOrgId()` from `@/lib/growth/access` | `setPlatformIdentityDefaultOrganizationId()` / `getGrowthEngineAiOrgId()` injectable hook |
| `server-only` import | Removed — package is platform-safe |
| `upsertWorkspacePreferencesForUser` for onboarding | Optional `setOnboardingCompletedForUser` adapter in `updatePlatformPersonaIdentity` |

## Persistence contract

Schema `growth` (documented only — **no migrations in this milestone**):

| Table | Role |
|-------|------|
| `organization_ai_teammate_identity` | Organization-scoped persona display name |
| `operator_workspace_preferences` | User onboarding flag (`ai_teammate_onboarding_completed`) |

## Identity vs Authentication

Authentication (Supabase Auth, sessions, tokens) remains in Equipify. This package accepts organization and user ids as **trusted inputs**; it does not verify sessions or credentials.

## Identity vs Authorization

RBAC, membership enforcement, and plan gates remain in Equipify. Role strings on persona identity (`Equipify's AI Growth Operator`) are **presentation metadata**, not permission grants.

## Identity vs Persona

Persona identity covers customer-renamable AI teammate presentation. AVA is the default historical display name, not the Fuzor platform identity. Persona voice, branding, and product UI remain outside this package.

## Identity vs Agent/Specialist

The seventeen `PlatformActorAgent` values are the constitutional work-order/event/decision vocabulary. Equipify's five `AvaSpecialistId` domain specialists are a separate registry — not extracted here.

## Identity vs Product

Contact/prospect resolution, Growth Engine operator profiles, and outbound sender identities are product concerns — excluded.

## Duplicated contracts in other Fuzor packages

| Location | Status after consolidation |
|----------|----------------------------|
| `@fuzor/event-bus` `PLATFORM_SPECIALIST_AGENTS` | Compatibility re-export from Identity |
| `@fuzor/decision-records` `PLATFORM_DECISION_OWNER_AGENTS` | Compatibility re-export from Identity |
| `@fuzor/memory` / `@fuzor/context` work-order agents | Import canonical `PLATFORM_ACTOR_AGENTS` |
| `@fuzor/knowledge` `org-resolver.ts` | **Unresolved** — injectable hook semantics differ from Identity/Configuration |

## Dependencies

- `@supabase/supabase-js` — persona repository only

No dependency on other `@fuzor/*` packages (acyclic foundation graph — actor catalog is consumed downstream).

## Foundation consolidation (FUZOR-FOUNDATION-CONSOLIDATION-1A)

**Canonical owner:** platform actor catalog (`PLATFORM_ACTOR_AGENTS`, guards, executive-brain classification).

Downstream packages import or re-export this catalog. The five-key Equipify `AvaSpecialistId` registry remains separate and was not merged.

Organization resolution and environment parsing boundaries were audited but **not merged** — see consolidation report for rationale.

## Limitations

- Contract-first: no unified identity graph, no CRUD beyond canonical persona paths
- No REST API, auth, RBAC, specialist registry, or Equipify adoption
- Onboarding persistence requires injectable adapter at update boundary
- Historical product strings (`Equipify's AI Growth Operator`, storage keys) preserved for parity

## Phase marker

`FUZOR_IDENTITY_PHASE = "FUZOR-IDENTITY-1F"`

## Known quirks preserved

- Default persona name remains `"Ava"` (presentation default, not platform identity)
- Autonomous activation upsert seeds `teammate_name: "Ava"` when activating
- Pronoun resolution uses fixed name sets (`ava`, `emma`, … → She; `alex`, … → They; default They)
- Invalid persona names fall back to default `"Ava"` via `sanitizePlatformPersonaName`
- Organization resolution fails closed when override is not a UUID or default is unset
