# @fuzor/context

Fuzor platform Context Assembly — the third runtime capability extracted from the canonical GE-AIOS-2J implementation.

## Purpose

Gathers read-only context from platform subsystems into immutable Context Packages keyed by Work Order. Context Assembly is infrastructure — it does not invoke LLMs, execute Work Orders, or create Decision Records.

## Public interfaces

| Export | Purpose |
|--------|---------|
| `assemblePlatformContextForWorkOrder` | Assemble or reuse context package with checksum dedupe |
| `getPlatformContextAssemblyRuntimeSummary` | Org-level assembly counters |
| `computePlatformContextPackageChecksum` | Stable SHA-256 checksum |
| `validatePlatformContextPackage` | Package validation |
| `assemblePlatformContextPackageContent` | Pure content assembly |
| `resolvePlatformContextEntityMetadata` | Entity intelligence projection |
| `evaluatePlatformContextAssemblyHealth` | Schema + runtime health |
| `probePlatformContextAssemblySchema` | Persistence readiness probe |

## Assembly pipeline

1. Fetch Work Order (anchor)
2. Read mission, decision records, memory registry entries, related events, entity metadata
3. Collect and normalize sections via `assemblePlatformContextPackageContent`
4. Compute checksum — reuse existing package if match (unless `forceReassemble`)
5. Validate package invariants
6. Persist append-only package + increment runtime counters
7. Publish `context.assembled`, `context.reused`, or `context.validation_failed`

## Invariants

1. **Read-only** — never mutates source stores
2. **Immutable packages** — append-only `ai_context_packages`
3. **Deterministic checksum** — stable sorted serialization → SHA-256
4. **Checksum reuse** — identical content returns existing package
5. **Validation before persist** — failures increment counter and emit event

## Dependencies

- `@fuzor/event-bus` — query related events, publish context events
- `@fuzor/decision-records` — read decision history

No circular dependencies. Future packages (Memory, Knowledge, Executive Brain) may depend on `@fuzor/context`.

## Persistence contract (Phase 1)

Schema `growth`:

- `ai_context_assembly_runtime`
- `ai_context_packages`

Read adapters (not owned): `ai_work_orders`, `organization_growth_objectives`, `ai_decision_records`, `ai_memory_registry`, `ai_os_events`, entity projection tables.

## Why infrastructure, not product logic

Context Assembly produces durable, immutable Context Packages for downstream consumers (Decision Engine, Provider adapters, Executive Brain). It references existing stores without duplicating product workflows, UI projections, or lead-scoped request memoization (Runtime Context 1A).

## Limitations

- No REST API in this package
- No LLM/provider invocation
- No Work Order execution or Decision Record creation
- Entity lead projection reads existing memory tables — not a full Memory Engine extraction

## Foundation consolidation (FUZOR-FOUNDATION-CONSOLIDATION-1A)

| Responsibility | Canonical owner | This package |
|----------------|-----------------|--------------|
| Memory registry types/bindings | `@fuzor/memory` | `memory-registry-types.ts`, `memory-source-registry.ts` re-export |
| Work-order agents | `@fuzor/identity` | `work-order-types.ts` imports canonical catalog |
| Memory registry read | Context-owned adapter | `memory-registry-read.ts` retained (assembly-specific mapping) |
| Legacy schema probe | `@fuzor/observability` | `schema-health.ts` adapter |

Dependencies added: `@fuzor/memory`, `@fuzor/identity`, `@fuzor/observability`. No `@fuzor/context` ↔ `@fuzor/memory` cycle.

## Future adoption points

- Equipify wrapper delegation (roadmap Phase 1)
- Production validation against `test-ge-aios-2j-context-assembly-foundation.ts`
- Optional Fuzor-owned persistence (separate ADR)

## Development

```bash
npm install
npm run typecheck --workspace @fuzor/context
npm test --workspace @fuzor/context
```
