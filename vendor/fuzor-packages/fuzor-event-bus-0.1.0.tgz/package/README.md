# @fuzor/event-bus

Fuzor platform Event Bus — the first runtime capability extracted from the canonical GE-AIOS-2B implementation.

## Purpose

Provides append-only platform event publishing, subscription matching, synchronous in-process dispatch, delivery tracking, replay, and corrections.

This package **promotes** the existing canonical implementation. It does not redesign transport, persistence semantics, or dispatch behavior.

## Public interfaces

| Export | Purpose |
|--------|---------|
| `publishPlatformEvent` | Insert event, create deliveries, invoke handlers synchronously |
| `publishPlatformEventCorrection` | Append corrective event with causation metadata |
| `registerPlatformEventSubscription` | Upsert org-scoped DB subscription |
| `getPlatformEvent` | Fetch event by ID |
| `queryPlatformEvents` | List events (desc by `occurred_at`) |
| `replayPlatformEventStream` | Replay events (asc by `occurred_at`) |
| `pullPlatformEventsForSubscriber` | Pull pending deliveries |
| `consumePlatformEventDelivery` | Mark delivery consumed |
| `archivePlatformEvent` | Append archive index record |
| `registerPlatformEventHandler` | Register in-process handler |
| `lookupPlatformEventRegistryEntry` | Resolve event type metadata |
| `subscriptionMatchesEvent` | Match subscription filters |
| `probePlatformEventSchema` | Persistence readiness probe |

## Internal interfaces

| Module | Role |
|--------|------|
| `repository.ts` | Supabase persistence (insert-only events) |
| `handler-registry.ts` | In-process handler map |
| `registry.ts` | Event type catalog |
| `persistence-contract.ts` | Table names and schema objects |
| `schema-health.ts` | Readiness probe |

## Invariants

1. Events are **append-only** — corrections emit new rows.
2. Dispatch is **synchronous** during publish — handlers run in-process.
3. `replay_key` provides idempotent bridged inserts when set.
4. `correlation_id` is assigned on publish when omitted.
5. Priority is clamped to `[0, 1000]` with non-finite default `500`.
6. Handler failures are isolated — publish succeeds; failures returned in result.

## Synchronous dispatch (preserved by design)

Phase 1 intentionally preserves synchronous in-process handler invocation because:

- The canonical implementation uses this model today.
- Downstream observers (learning, draft factory wake, executive observation) depend on publish-tick semantics.
- Changing to async messaging would alter production behavior.

Async queues and distributed messaging require a separate ADR and roadmap phase.

## Persistence (Phase 1)

Uses existing tables in schema `growth`:

- `ai_os_events`
- `ai_os_event_subscriptions`
- `ai_os_event_deliveries`
- `ai_os_event_archive_records`

Database ownership migration is **not** part of this milestone.

## Assumptions

- Caller provides Supabase service-role client with access to persistence tables.
- Organization isolation is enforced by caller context and query filters.
- Registry event type strings remain compatible with persisted historical events.

## Limitations

- No REST API surface in this package.
- No product bridge implementations (legacy bridges remain in product code until adapter milestone).
- No GE-AI-2B wrapper envelope layer — canonical substrate only.
- Schema health probe performs lightweight table readability checks only.

## Future extraction points

- Equipify publish delegation wrapper (Extraction Plan Step 3)
- Subscriber registry authority consolidation
- Retire duplicate publish APIs in product wrapper layer
- Optional Fuzor-owned persistence (separate ADR)

## Dependencies

- `@fuzor/identity` — canonical platform actor catalog (consolidated in FUZOR-FOUNDATION-CONSOLIDATION-1A)
- `@fuzor/observability` — legacy schema probe substrate for `probePlatformEventSchema` (consolidated in FUZOR-FOUNDATION-CONSOLIDATION-1A)
- `@supabase/supabase-js` — persistence

## Foundation consolidation (FUZOR-FOUNDATION-CONSOLIDATION-1A)

| Responsibility | Canonical owner | This package |
|----------------|-----------------|--------------|
| Actor catalog | `@fuzor/identity` | `specialist-agents.ts` re-exports `PLATFORM_SPECIALIST_AGENTS` |
| Correlation ID generation | `@fuzor/event-bus` | `buildPlatformEventCorrelationId` remains authoritative |
| Legacy schema probe | `@fuzor/observability` | `schema-health.ts` uses `probePlatformSchemaObjectsForLegacyReadySummary` |

Removed duplicate actor enum and inline PostgREST probe loop. Public exports and `{ ready, missingObjects }` health shape unchanged.

## Development

```bash
npm install
npm run typecheck --workspace @fuzor/event-bus
npm test --workspace @fuzor/event-bus
```
