# @fuzor/observability

Fuzor platform Observability — the eighth runtime capability extracted from the canonical Equipify schema-health substrate (`growth-schema-health-types`, `growth-postgrest-table-probe`, `blitzpay-schema-health-detect`) and shared diagnostic/correlation contracts.

## Purpose

Observability is a **contract-first** platform package. Equipify has no single cross-platform telemetry service; reusable behavior lives in schema probe aggregation, PostgREST error classification, diagnostic issue shapes, and correlation context normalization. Product aggregators (Command Center, Operations Dashboard, Runtime Observability) remain in Equipify.

**Observability reports operational condition — it does not own domain audit persistence or event history.**

## Capability classification

| Domain | In this package | Classification |
|--------|-----------------|----------------|
| Schema health summary (`ready/verified/uncertain`) | Yes | Canonical platform observability |
| PostgREST table probes + cache | Yes | Canonical platform observability |
| PostgREST missing-schema heuristics | Yes | Canonical platform observability |
| Diagnostic issue `{ code, severity, message }` | Yes | Shared diagnostic contract |
| Correlation/causation context | Yes | Shared contract (Event Bus owns publication) |
| Per-capability schema probes | No | Capability-local (stay in domain packages) |
| Command Center / Operations Dashboard | No | Product diagnostics |
| Runtime config health / autonomy tick health | No | Certification + product diagnostics |
| Provider config diagnostics runtime | No | Provider/product wiring |
| OpenTelemetry / metrics / alerting | No | Out of scope |

## Canonical sources

| Module | Equipify source |
|--------|-----------------|
| Schema health types | `lib/growth/schema-health/growth-schema-health-types.ts` |
| PostgREST probe | `lib/growth/schema-health/growth-postgrest-table-probe.ts` |
| Schema error detect | `lib/blitzpay/blitzpay-schema-health-detect.ts` |
| Diagnostic issue pattern | `lib/growth/providers/pdl/pdl-config-diagnostics.ts` |
| Correlation semantics | `lib/growth/aios/ai-event-types.ts` (aligned with `@fuzor/event-bus`) |

## Health status model

| Field / outcome | Meaning |
|-----------------|---------|
| `ready` | No missing schema objects |
| `verified` | No missing objects and no uncertain probes |
| `uncertain` | Probe inconclusive with no missing objects (e.g. cache stale) |
| Probe outcome `detected` | Object accessible |
| Probe outcome `missing` | Definitive missing relation/column |
| Probe outcome `uncertain` | Inconclusive (cache, network, credentials) |

**Not unified with:** `READY/WARN/MISSING` (runtime guardrails), `healthy/degraded/blocked` (operations dashboard), or simplified `{ ready }` summaries in existing Fuzor packages — documented for future consolidation.

## Public interfaces

| Export | Responsibility |
|--------|----------------|
| `summarizePlatformSchemaProbeResults` | Pure aggregation of probe outcomes |
| `mergePlatformSchemaHealthSummaries` | Cross-probe merge (deduped missing objects) |
| `probePlatformSchemaObjects` | Cached PostgREST schema object probe |
| `looksLikePostgrestMissingSchemaError` | Schema drift error heuristics |
| `normalizePlatformDiagnosticIssue` | Diagnostic issue normalization |
| `orderPlatformDiagnosticIssuesDeterministically` | Severity/code ordering utility |
| `normalizePlatformCorrelationContext` | Correlation/causation normalization |
| `buildPlatformCorrelationId` | UUID or seed correlation id (same semantics as Event Bus) |

## Observability vs Capability Health

Each `@fuzor/*` package continues to own its capability-specific probe catalog and readiness rules. This package provides the **shared substrate** those probes should use — it does not copy Event Bus, Memory, or Knowledge probe implementations.

## Observability vs Audit

Domain audit tables (`runtime_guardrail_audit_log`, decision audits, registry events) remain domain-owned. This package does not create a universal audit ledger.

## Observability vs Event Bus

Event history, replay, and archive indexing remain in `@fuzor/event-bus`. Correlation ID generation semantics align with `buildPlatformEventCorrelationId` — Event Bus remains publication authority.

## Observability vs Configuration

Configuration readiness (kill switches, profiles) stays in `@fuzor/configuration`. Observability may consume configuration facts in future aggregators — not in this extraction.

## Sensitive data boundary

- No production diagnostic payloads, credentials, or customer data in source or tests
- REST probe fallback reads `SUPABASE_SERVICE_ROLE_KEY` from environment at runtime only — never stored in repository
- Diagnostic messages are operational strings; no API keys in issue codes

## Dependencies

- `@fuzor/event-bus` — canonical correlation ID semantics (`buildPlatformEventCorrelationId`; identical logic in this package to avoid dependency cycle with schema probe imports)
- `@supabase/supabase-js` — PostgREST probes only

## Duplicated contracts in other Fuzor packages

| Location | Status after consolidation |
|----------|----------------------------|
| Domain package `{ ready }` schema health | Uses `probePlatformSchemaObjectsForLegacyReadySummary` from this package |
| `@fuzor/configuration` kill-switch table probe | **Retained locally** — configuration-specific readiness |
| `@fuzor/knowledge` signal foundation probe | **Retained locally** — memoized boolean probe semantics |
| Rich `ready/verified/uncertain` vs simplified `{ ready }` | **Not unified** — requires separate ADR |

## Foundation consolidation (FUZOR-FOUNDATION-CONSOLIDATION-1A)

**Shared substrate owner** for PostgREST table probing and legacy `{ ready, missingObjects }` aggregation.

Added `legacy-schema-probe.ts` preserving domain-package semantics (any probe error → missing). Rich probe/cache behavior remains in `postgrest-probe.ts`.

**Correlation:** Event Bus owns generation authority. Identical `buildPlatformCorrelationId` logic is retained here (not imported) because `@fuzor/event-bus` imports this package's legacy schema probe — an import would create a dependency cycle. Consolidation tests prove semantic parity.

## Phase marker

`FUZOR_OBSERVABILITY_PHASE = "FUZOR-OBSERVABILITY-1H"`

## Limitations

- Contract-first: no Command Center aggregator, no metrics collector, no logging framework
- No REST API, OpenTelemetry, alerting, or Equipify adoption
- Schema health is infrastructure-scoped (not organization-tenant scoped in canonical source)
- Competing health vocabularies intentionally not merged

## Known quirks preserved

- `ready=true` allowed while `verified=false` when probes are uncertain
- Warning messages reference "Growth Engine migrations" (historical parity string)
- `PLATFORM_SCHEMA_DRIFT_PUBLIC_MESSAGE` retains BlitzPay product string for heuristic parity
- Probe cache TTL 15 seconds (`PLATFORM_SCHEMA_HEALTH_PROBE_CACHE_MS`)
