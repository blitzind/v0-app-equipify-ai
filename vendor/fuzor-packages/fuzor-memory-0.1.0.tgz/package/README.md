# @fuzor/memory

Fuzor platform Memory — the fifth runtime capability extracted from the canonical GE-AIOS-12A / 17B organizational memory engine and GE-AIOS-2F memory registry.

## Purpose

Provides deterministic organizational memory synthesis, durable event/preference persistence, metadata registry, and read models for downstream platform consumers. Memory is infrastructure — it does not invoke LLMs, execute missions, or perform autonomous actions.

## Public interfaces

| Export | Purpose |
|--------|---------|
| `runPlatformMemoryEngine` | Deterministic memory synthesis from workspace signals |
| `mergePlatformOrganizationalMemoryStore` | Client-side merge with caps (500 events / 50 preferences) |
| `upsertPlatformOrganizationMemoryEvents` | Server persistence to `organization_memory_events` |
| `fetchPlatformOrganizationMemoryStore` | Server read model with degradation handling |
| `registerPlatformMemoryRegistryEntry` | Register metadata in `ai_memory_registry` |
| `linkPlatformMemoryRegistryToWorkOrder` | Link registry entry + append work-order memory ref |
| `queryPlatformMemoryRegistry` | List/filter registry entries |
| `buildPlatformOrganizationalKnowledge` | Deterministic 17C promotion facet (BI + memory events) |
| `detectPlatformMemoryPatterns` | Pattern facet |
| `applyPlatformMemoryToDecisionContext` | Decision bridge (confidence boost) |

## Memory lifecycle

1. **Ingest signals** — workspace summary, queue, accomplishments, timeline, adapters
2. **Synthesize events** — deterministic categorization and importance scoring
3. **Merge store** — append-only merge with caps; server canonical over localStorage fallback
4. **Persist** — upsert to `growth.organization_memory_events` / `organization_memory_preferences`
5. **Register** — metadata registry references source tables (no source-store writes)
6. **Publish** — `memory.registered|referenced|linked|archived` via `@fuzor/event-bus`

## Invariants

1. **Deterministic only** — `rememberConversation`, `rememberOutcome`, etc. return stub negatives
2. **Server-canonical** — `resolvePersistedOrganizationalMemoryStore` prefers server when healthy
3. **Registry metadata only** — never inserts into bound source tables
4. **Permanent retention guard** — archive rejects `retentionPolicy: permanent`
5. **Organization scoped** — repository filters enforce `organization_id`
6. **QA markers preserved** — persistence field names unchanged for compatibility

## Dependencies

- `@fuzor/event-bus` — registry event publication
- `@fuzor/decision-records` — link validation for decision records
- `@supabase/supabase-js` — persistence

No dependency on `@fuzor/context` or `@fuzor/knowledge` (acyclic graph).

## Persistence contract

Schema `growth`:

| Table | Role |
|-------|------|
| `organization_memory_events` | Durable org memory events (17B) |
| `organization_memory_preferences` | Org preferences (17B) |
| `organization_knowledge` | Promoted conclusions (17C facet — Knowledge Center table) |
| `ai_memory_registry` | Metadata registry (2F) |
| `ai_memory_registry_events` | Registry audit trail (2F) |

## Memory vs Knowledge vs Context

| System | Owns |
|--------|------|
| **@fuzor/memory** | Org memory events, preferences, registry metadata, engine synthesis, 17C promotion builder |
| **@fuzor/knowledge** | Knowledge Center documents in `signal_events` (GS-3A–3D) |
| **@fuzor/context** | Read-only context assembly; imports registry contracts from `@fuzor/memory` (consolidated 1A) |

## Context overlap (resolved in FUZOR-FOUNDATION-CONSOLIDATION-1A)

Context re-exports canonical registry types and source bindings from `@fuzor/memory`. Context retains assembly-specific read adapters and projections — write authority stays in Memory.

## Foundation consolidation (FUZOR-FOUNDATION-CONSOLIDATION-1A)

| Responsibility | Canonical owner | This package |
|----------------|-----------------|--------------|
| Work-order agents | `@fuzor/identity` | `work-order-types.ts` imports `PLATFORM_ACTOR_AGENTS` |
| Registry contracts | `@fuzor/memory` | Exported for Context consumption |
| Legacy schema probe | `@fuzor/observability` | `registry-schema-health.ts` adapter |

Dependencies added: `@fuzor/identity`, `@fuzor/observability`.

## Limitations

- No REST API in this package
- No LLM/embedding/vector search
- No lead-memory CRM store (product Layer 2)
- No Equipify adoption or delegation
- Adapter input types are structural mirrors of product workspace payloads

## Future adoption points

- Equipify wrapper delegation (roadmap Phase 2)
- Context package re-import of registry types/bindings
- Production validation against Equipify certification scripts
- Inventory status: **Extracted (Not Adopted)**

## Development

```bash
npm install
npm run typecheck --workspace @fuzor/memory
npm test --workspace @fuzor/memory
```
