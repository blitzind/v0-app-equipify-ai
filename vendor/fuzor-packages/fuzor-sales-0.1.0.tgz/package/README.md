# @fuzor/sales

Shared Fuzor Sales runtime — deployment-neutral GPT-5.5 sales reasoning consumed by Equipify Ava and Blitzify Sal.

## Milestone

FUZOR-SALES-RUNTIME-EXTRACTION-1A — evidence → GPT-5.5 judgment → personalized outreach draft (no send).
