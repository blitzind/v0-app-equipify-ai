# @fuzor/sdk

Stable public integration surface for the production-certified Fuzor Platform.

## Philosophy

The SDK is a **delegation layer** — not a platform capability. It organizes public APIs from independently versioned `@fuzor/*` packages under stable namespaces.

Products import from `@fuzor/sdk` instead of reaching into individual platform packages directly.

## Usage

```typescript
import {
  Identity,
  Configuration,
  Knowledge,
  Memory,
  Context,
  DecisionRecords,
  EventBus,
  Observability,
} from "@fuzor/sdk"

// Or use aliases:
import { Decisions, Events } from "@fuzor/sdk"

const actors = Identity.PLATFORM_ACTOR_AGENTS
const profile = Configuration.getPlatformRuntimeProfile("operator_minimal")
```

## Namespaces

| Namespace | Package | Responsibility |
|-----------|---------|----------------|
| `Identity` | `@fuzor/identity` | Actors, org resolution, persona |
| `Configuration` | `@fuzor/configuration` | Runtime profiles, features, calibration |
| `Knowledge` | `@fuzor/knowledge` | Knowledge repository and retrieval |
| `Memory` | `@fuzor/memory` | Organizational memory and registry |
| `Context` | `@fuzor/context` | Context assembly |
| `DecisionRecords` | `@fuzor/decision-records` | Decision persistence |
| `EventBus` | `@fuzor/event-bus` | Event transport |
| `Observability` | `@fuzor/observability` | Schema health, diagnostics |

## Subpath imports

```typescript
import * as Identity from "@fuzor/sdk/identity"
```

## Versioning

Semver applies to `@fuzor/sdk` as the stable public surface. Internal `@fuzor/*` packages remain independently maintainable.

Test-only symbols (`*ForTests`) are excluded from SDK exports.
