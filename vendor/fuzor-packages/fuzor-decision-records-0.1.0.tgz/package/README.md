# @fuzor/decision-records

Fuzor platform Decision Records — the second runtime capability extracted from the canonical GE-AIOS-2D implementation.

## Purpose

Provides append-only decision persistence, lifecycle audit trails, supersede lineage, work order linkage, and event publication via the platform Event Bus.

This package **promotes** the existing canonical implementation. It does not redesign reasoning, persistence semantics, or dispatch behavior.

## Public interfaces

| Export | Purpose |
|--------|---------|
| `createPlatformDecisionRecord` | Insert record, audit event, optional work order link, publish `decision.recorded` |
| `supersedePlatformDecisionRecord` | Append successor row with lineage, audit both rows, publish supersede + recorded |
| `linkPlatformDecisionRecordToWorkOrder` | Append to work order `decision_record_ids`, audit link, publish `decision.linked` |
| `getPlatformDecisionRecord` | Fetch record by ID |
| `queryPlatformDecisionRecords` | List records (desc by `created_at`) |
| `getPlatformDecisionRecordAuditTrail` | List lifecycle audit events |
| `lookupPlatformDecisionRegistryEntry` | Resolve decision key metadata |
| `probePlatformDecisionRecordSchema` | Persistence readiness probe |

Repository-level exports (`insertPlatformDecisionRecord`, etc.) are also available for advanced integration.

## Internal interfaces

| Module | Role |
|--------|------|
| `repository.ts` | Supabase persistence (insert-only records) |
| `decision-record-service.ts` | Orchestration, event publication, work order linkage |
| `registry.ts` | Constitutional decision key catalog |
| `work-order-linkage.ts` | Minimal work order `decision_record_ids` read/update |
| `persistence-contract.ts` | Table names and schema objects |
| `schema-health.ts` | Readiness probe |

## Persistence contract (Phase 1)

Uses existing tables in schema `growth`:

- `ai_decision_records` — immutable insert-only decision log
- `ai_decision_record_audit_events` — append-only lifecycle audit
- `ai_work_orders.decision_record_ids[]` — linkage only (not full Work Order extraction)

Database ownership migration is **not** part of this milestone.

## Invariants

1. Decision rows are **insert-only** — supersede creates new rows with `supersedes_decision_id`.
2. Lifecycle changes are recorded in the audit table — record rows are never updated.
3. Confidence and risk scores are clamped to `[0, 100]`.
4. Decision Records publish platform events — they do not invoke AI, providers, or Memory.
5. Work order linkage appends IDs without duplicating entries.
6. Event publication uses `@fuzor/event-bus` with synchronous dispatch preserved.

## Behavioral guarantees (parity preserved)

- Same QA marker: `growth-aios-2d-decision-record-v1`
- Same schema version: `1.0`
- Same event types: `decision.recorded`, `decision.superseded`, `decision.linked`
- Same producer/source strings on published events: `ai_decision_record_service`
- Same correlation/causation semantics on published events
- Same query ordering: descending by `created_at`

## Assumptions

- Caller provides Supabase service-role client with access to persistence tables.
- Organization isolation is enforced by caller context and query filters.
- `@fuzor/event-bus` is available for event publication (workspace dependency).

## Limitations

- No REST API surface in this package.
- No Decision Engine (GE-AIOS-2H) reasoning layer — substrate only.
- No fingerprint/freshness resolver — that lives in a separate product layer, not GE-AIOS-2D.
- Registry catalog is advisory — repository validates owner agent only, not decision key enforcement.
- Work order linkage reads/updates only `decision_record_ids` — not a full Work Order extraction.

## Foundation consolidation (FUZOR-FOUNDATION-CONSOLIDATION-1A)

| Responsibility | Canonical owner | This package |
|----------------|-----------------|--------------|
| Decision owner agents | `@fuzor/identity` | `owner-agents.ts` compatibility re-export |
| Legacy schema probe | `@fuzor/observability` | `schema-health.ts` adapter retains public summary shape |

Dependencies added: `@fuzor/identity`, `@fuzor/observability`.

## Future adoption points

- Equipify wrapper delegation to `@fuzor/decision-records` (roadmap Phase 1 Step 3)
- Production validation against Equipify certification script
- Optional Fuzor-owned persistence (separate ADR)
- Consolidation with Decision Engine write path (Phase 3)

## Development

```bash
npm install
npm run typecheck --workspace @fuzor/decision-records
npm test --workspace @fuzor/decision-records
```
