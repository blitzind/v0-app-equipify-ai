# @fuzor/knowledge

Fuzor platform Knowledge Center — the fourth runtime capability extracted from the canonical GS-3A through GS-3D implementation.

## Purpose

Provides deterministic knowledge ingestion, classification, search, retrieval, read-only context injection, and citation-backed recommendations. Knowledge Center is platform infrastructure — it does not invoke LLMs, execute missions, or perform autonomous actions.

## Public interfaces

| Export | Purpose |
|--------|---------|
| `ingestPlatformKnowledgeDocument` | Normalize and classify a knowledge document |
| `classifyPlatformKnowledgeDocument` | Deterministic category classification |
| `searchPlatformKnowledge` | Filter and rank documents in memory |
| `retrievePlatformKnowledgeForConsumer` | Consumer-scoped retrieval with relevance scoring |
| `buildPlatformKnowledgeConsumerContextFromDocuments` | Bucket documents into consumer context |
| `injectPlatformKnowledgeContext` | Server path: retrieve + audit to `signal_events` |
| `generatePlatformKnowledgeRecommendations` | Citation-backed recommendations from context |
| `createPlatformKnowledgeDocument` | Persist ingested document to `signal_events` |
| `runPlatformKnowledgeSearch` | List + search persisted documents |
| `probePlatformKnowledgeSignalFoundationSchema` | Signal foundation readiness probe |

## Knowledge lifecycle

1. **Ingest** — normalize content by source type (URL, file, text, FAQ), classify, tag, summarize
2. **Persist** — append document payload to `growth.signal_events` (`event_type=ingested`, QA marker `growth-knowledge-center-gs3a-v1`)
3. **Search** — deterministic token scoring over title, tags, categories, content
4. **Retrieve** — consumer defaults + filters (active-only, visibility, org scope)
5. **Context inject** — bucket into playbooks, objections, competitors, etc.; audit event `knowledge_context_retrieved`
6. **Recommend** — deterministic, citation-required suggestions per consumer; audit event `knowledge_recommendations_generated`

## Invariants

1. **Human review required** — `requires_human_review: true` on all documents and outputs
2. **No autonomous execution** — `autonomous_execution_enabled: false` everywhere
3. **Active-only retrieval** — draft, archived, and review-status documents excluded
4. **Citation required** — every recommendation must cite `document_id`, `title`, and `category`
5. **Deterministic ordering** — relevance score, then `updated_at` descending
6. **Persistence contract preserved** — same `growth.signal_events` payload shape as canonical source

## Dependencies

- `@supabase/supabase-js` — persistence reads/writes only

No dependency on `@fuzor/context`, `@fuzor/decision-records`, or `@fuzor/event-bus` (canonical source had none). Future packages may depend on `@fuzor/knowledge`.

## Persistence contract (Phase 1)

Schema `growth`:

- **Documents:** `signal_events` with `event_payload.qa_marker = growth-knowledge-center-gs3a-v1`
- **Context audit:** `signal_events` with `growth-knowledge-context-gs3c-v1`
- **Recommendation audit:** `signal_events` with `growth-knowledge-recommendations-gs3d-v1`
- **Schema probe:** `growth.signals` (signal foundation readiness — same probe as Equipify)

## Organization resolution

Equipify previously defaulted `organization_id` via product access. Fuzor requires explicit `organization_id` on server requests, or set `setPlatformKnowledgeDefaultOrganizationId()` for adoption scenarios.

## Why infrastructure, not product logic

Knowledge Center stores and retrieves platform knowledge artifacts for downstream consumers (specialists, mission engine, copilots). It does not encode product workflows, REST routing, UI projections, or LLM orchestration.

## Limitations

- No REST API in this package
- No LLM/embedding/vector search
- No Memory Engine, Executive Brain, or Mission Engine
- Certification scripts remain in Equipify (not extracted)

## Future adoption points

- Equipify wrapper delegation (roadmap Phase 1)
- Production validation against Equipify certification scripts
- Inventory status: **Extracted (Not Adopted)**

## Development

```bash
npm install
npm run typecheck --workspace @fuzor/knowledge
npm test --workspace @fuzor/knowledge
```
