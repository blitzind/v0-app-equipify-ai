# @fuzor/configuration

Fuzor platform Configuration — the seventh runtime capability extracted from canonical Equipify configuration substrates (GS-RG-1 runtime guardrails, GE-AI-3D-PROD-3 calibration overlays, Growth Engine platform enablement env contracts, Phase 8G runtime profiles).

## Purpose

Configuration is a **contract-first, resolver-first** platform package. Equipify does not expose one universal settings service; reusable behavior lives in domain-owned limits, kill-switch resolution, calibration merge rules, environment parsing, and runtime profile selection. This package extracts those substrates without policy evaluation, secrets management, product UI settings, or runtime consumption state.

**Configuration answers what value is selected — not whether an action is permitted.**

## Capability classification

| Domain | In this package | Classification |
|--------|-----------------|----------------|
| Runtime guardrail limits & kill switches | Yes | Canonical platform configuration |
| Calibration default registry & merge resolver | Yes | Organization-scoped configuration overlay |
| `GROWTH_ENGINE_*` enablement env parsing | Yes | Environment configuration |
| Runtime profile selection | Yes | Environment + registry-backed posture |
| Feature registry catalog | Exported | Registry (not enforcement) |
| Autonomy org settings & policy engine | No | Policy + product settings |
| Operator workspace preferences | No | User preferences |
| Provider API keys | No | Secrets / provider wiring |
| `runtime_budgets` consumption | No | Runtime state |
| Feature-flag cascades (`GROWTH_*` scattered flags) | No | Feature flags (no canonical authority) |

## Canonical sources

| Module | Equipify source |
|--------|-----------------|
| Runtime guardrails | `lib/growth/runtime-guardrails/growth-runtime-guardrail-config.ts` |
| Kill switch resolution | `lib/growth/runtime-guardrails/growth-runtime-kill-switch-service.ts` |
| Calibration registry | `lib/growth/aios/learning/growth-adaptive-calibration-config-registry.ts` |
| Calibration resolver | `lib/growth/aios/learning/growth-adaptive-calibration-config-resolver.ts` |
| Platform enablement env | `lib/growth/growth-engine-session.ts` (env readers only) |
| Runtime profiles | `lib/growth/runtime/growth-runtime-profile.ts` |
| Feature registry | `lib/growth/runtime/growth-feature-registry.ts` (catalog) |

## Precedence models

### Kill switches
```
growth.runtime_guardrail_settings.enabled (when table exists)
  > PLATFORM_RUNTIME_DEFAULT_KILL_SWITCHES[key]
  > true (unknown keys — fail-open for new switches)
Missing table → full code defaults
```

### Calibration effective config
```
explicit activeConfig input
  > in-memory override (test/cert hook)
  > registry defaults (PLATFORM_CALIBRATION_DEFAULT_CONFIG)
Merge: { ...defaults, ...active }
```

### Platform enablement
```
GROWTH_ENGINE_ENABLED.trim() === "true"  → enabled (case-sensitive "true")
GROWTH_ENGINE_AI_ORG_ID trimmed UUID    → org id or null if invalid/missing
```

### Runtime profile
```
GROWTH_RUNTIME_PROFILE (valid id)
  > NEXT_PUBLIC_GROWTH_RUNTIME_PROFILE (valid id)
  > production heuristic → operator_minimal
  > non-production → development_all
```

## Public interfaces

| Export | Responsibility |
|--------|----------------|
| `PLATFORM_RUNTIME_GUARDRAIL_LIMITS` | Hard runtime caps catalog |
| `getPlatformBudgetCapForResource` | Daily/hourly cap lookup (`0` = unlimited for guardrails) |
| `isPlatformRuntimeKillSwitchEnabled` | DB-backed kill switch with code defaults |
| `resolvePlatformEffectiveCalibrationConfig` | Org-scoped calibration merge |
| `isPlatformGrowthEngineEnabledEnv` | `GROWTH_ENGINE_ENABLED` parsing |
| `readPlatformGrowthEngineAiOrgIdFromEnv` | `GROWTH_ENGINE_AI_ORG_ID` UUID parsing |
| `resolvePlatformRuntimeProfileId` | Active runtime profile selection |
| `PLATFORM_FEATURE_REGISTRY` | Static capability tier catalog (registry) |

## Configuration vs Policy

Kill switches and guardrail caps **gate runtime execution** but autonomy approval, outbound authorization, and capability evaluation remain in Equipify policy engines. Calibration overlays adjust ranking weights — they do not bypass constitutional apply rules (`PLATFORM_CALIBRATION_APPLY_RULE`).

## Configuration vs Runtime State

`runtime_budgets` consumption counters, scheduler leases, and pilot telemetry are runtime state — not extracted. Guardrail caps are configuration; consumption against them is state.

## Configuration vs Identity

Organization UUIDs are accepted as explicit inputs. `@fuzor/identity` owns workspace organization resolution ports; `@fuzor/configuration` owns `GROWTH_ENGINE_*` environment parsing. Overlap with identity/knowledge injectable org hooks is documented for future consolidation — not resolved in this milestone.

## Configuration vs Registry

`PLATFORM_FEATURE_REGISTRY` documents intended capability tiers. Phase 8G registry is **not enforcement** — exported as catalog only.

## Known platform debt (not resolved here)

**Budget zero semantics conflict:** Guardrail daily caps treat `0` as **unlimited**; autonomy daily budgets treat `0` as **disabled**. Both reference overlapping autonomous resource types — do not unify without an explicit normalization milestone.

**Server vs client feature flags:** `GROWTH_*` and `NEXT_PUBLIC_*` flags have no single canonical resolver — excluded from this package.

## Persistence contract

Documented only — **no migrations in this milestone**:

| Table | Schema | Role |
|-------|--------|------|
| `runtime_guardrail_settings` | growth | Platform kill switches |
| `runtime_budgets` | growth | Consumption state (documented, not owned) |
| `calibration_active_config` | growth | Org calibration overlay |
| `calibration_config_versions` | growth | Version history |

## Environment boundary

- Preserves exact variable names: `GROWTH_ENGINE_ENABLED`, `GROWTH_ENGINE_AI_ORG_ID`, `GROWTH_RUNTIME_PROFILE`, `NEXT_PUBLIC_GROWTH_RUNTIME_PROFILE`, `VERCEL_ENV`, `NEXT_PUBLIC_VERCEL_ENV`, `NODE_ENV`
- No `.env.local`, no dotenv loading, no production value copies
- Tests use `setPlatformConfigurationEnvReaderForTests` / `setPlatformRuntimeProfileEnvReaderForTests`

## Secret handling

No secrets extracted. Provider API keys, Supabase service keys, and OAuth credentials remain in Equipify environment configuration — out of scope.

## Dependencies

- `@supabase/supabase-js` — kill switch persistence reads/writes only

No dependency on other `@fuzor/*` packages.

## Duplicated contracts in other Fuzor packages

| Location | Classification |
|----------|----------------|
| `@fuzor/identity` / `@fuzor/knowledge` org injectable hooks | Environment resolver duplicate → future consolidation |
| `@fuzor/event-bus` priority clamp defaults | Package-local invariant |
| `@fuzor/knowledge` retrieval weights | Package-local / domain config |
| `@fuzor/memory` pattern thresholds | Package-local invariant |

## Phase marker

`FUZOR_CONFIGURATION_PHASE = "FUZOR-CONFIGURATION-1G"`

## Limitations

- Contract-first: no universal configuration repository or mega-resolver
- No REST API, secrets manager, feature-flag service, or Equipify adoption
- Autonomy settings, operator preferences, and provider secrets excluded
- Feature registry exported without Phase 8H enforcement wiring
