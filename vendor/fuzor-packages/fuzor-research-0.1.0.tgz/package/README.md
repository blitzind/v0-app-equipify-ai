# @fuzor/research

Shared Fuzor public company research — website retrieval, domain normalization, and evidence provenance.

Milestone: FUZOR-SALES-RUNTIME-1B.
