window.initEquipifyGrowthIntakeApp({ surface: "popup" })
