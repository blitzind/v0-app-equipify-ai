window.initEquipifyGrowthIntakeApp({ surface: "sidepanel" })
