window.initEquipifyGrowthIntakeApp({ surface: "inpage" })
